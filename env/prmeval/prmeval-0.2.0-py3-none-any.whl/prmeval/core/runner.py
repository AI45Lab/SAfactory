from __future__ import annotations

import json
import logging
import sys
from collections.abc import Iterable
from pathlib import Path
from typing import Any, TypeVar

from tqdm import tqdm

from prmeval.infer.base import Infer
from prmeval.infer.baselines import load_builtin_infer
from prmeval.metrics.builtins import _detail_keys, compute_metrics
from prmeval.sample.samplers import EvalSampler

from .config import EvalConfig, InferConfig
from .registry import INFERS, SAMPLERS
from .schemas import (
    EvaluationRecord,
    EvaluationSample,
    Prediction,
    PreferencePrediction,
    PreferenceSample,
    ProgressPrediction,
    ProgressSample,
)
from .storage import (
    append_inference_records,
    clear_non_string_frame_values,
    prepare_inference_outputs,
    save_trajectories,
    write_metric_details_jsonl,
)
from .utils import batched, read_jsonl

logger = logging.getLogger(__name__)
T = TypeVar("T")


class Evaluator:
    def __init__(self, config: EvalConfig, show_progress: bool = True):
        self.config = config
        self.show_progress = show_progress and sys.stderr.isatty()
        self.output_dir = Path(config.output_dir) / config.task_name if config.output_dir is not None else None
        self.samples_path = self.output_dir / "samples.jsonl" if self.output_dir is not None else None
        self.predictions_path = self.output_dir / "predictions.jsonl" if self.output_dir is not None else None
        self.errors_path = self.output_dir / "errors.jsonl" if self.output_dir is not None else None
        self.metrics_path = self.output_dir / "metrics.json" if self.output_dir is not None else None
        self.metrics_detail_path = self.output_dir / "metrics_detail.jsonl" if self.output_dir is not None else None

        self.sampler: EvalSampler | None = None

    def _with_progress(
        self,
        iterable: Iterable[T],
        *,
        description: str,
        unit: str,
        total: int | None = None,
    ) -> Iterable[T]:
        if not self.show_progress:
            return iterable
        return tqdm(
            iterable,
            desc=description,
            unit=unit,
            total=total,
            file=sys.stderr,
            dynamic_ncols=True,
        )

    def _build_coverage_summary(
        self, *, successful_ids: set[str], failed_ids: set[str], total: int, executed: int, skipped: int
    ) -> dict[str, int]:
        return {
            "total": total,
            "successful": len(successful_ids),
            "failed": len(failed_ids - successful_ids),
            "executed": executed,
            "skipped": skipped,
        }

    def _run_inference_batch(
        self,
        infer: Infer,
        sources: list[EvaluationRecord],
        samples: list[EvaluationSample],
    ) -> list[EvaluationRecord]:
        def validate_prediction_for_sample(sample: EvaluationSample, prediction: Prediction) -> None:
            """Check prediction identity, type, and length against the hydrated sample."""
            if prediction.sample_id != sample.sample_id:
                raise ValueError(
                    f"Prediction sample_id mismatch: expected {sample.sample_id}, got {prediction.sample_id}"
                )
            if prediction.status == "error":
                return
            if isinstance(sample, ProgressSample):
                if not isinstance(prediction, ProgressPrediction):
                    raise TypeError(f"Progress sample requires ProgressPrediction, got {type(prediction).__name__}")
                expected = len(sample.trajectory.frames)
                actual = len(prediction.progress)
                if actual != expected:
                    raise ValueError(f"Progress length mismatch: expected {expected}, got {actual}")
            elif isinstance(sample, PreferenceSample) and not isinstance(prediction, PreferencePrediction):
                raise TypeError(f"Preference sample requires PreferencePrediction, got {type(prediction).__name__}")

        def build_inference_record(
            source: EvaluationRecord,
            config: InferConfig,
            prediction: Prediction | None = None,
            error: str | None = None,
            raw_response: Any = None,
        ) -> EvaluationRecord:
            """Attach the prediction or failure information to new record."""
            if error is not None:
                prediction = Prediction(
                    sample_id=source.sample.sample_id,
                    infer_name=config.name,
                    status="error",
                    model=config.model_id or config.model_path or config.name,
                    error=error,
                    raw_response=raw_response,
                )
            elif prediction is None:
                raise ValueError("An inference record requires a prediction or an error")
            elif prediction.infer_name != config.name:
                prediction = prediction.model_copy(update={"infer_name": config.name})
            return EvaluationRecord(
                eval_type=source.eval_type,
                sample=source.sample,
                prediction=prediction,
            )

        if not samples:
            return []
        try:
            infer.begin_prediction()
            predictions = infer.predict(samples)
            if not isinstance(predictions, list):
                raise TypeError(f"Infer.predict() must return a list, got {type(predictions).__name__}")
            expected_ids = [sample.sample_id for sample in samples]
            actual_ids = [prediction.sample_id for prediction in predictions]
            if len(predictions) != len(samples):
                raise ValueError(f"Batch prediction count mismatch: expected {len(samples)}, got {len(predictions)}")
            if len(actual_ids) != len(set(actual_ids)):
                raise ValueError("Batch predictions contain duplicate sample_id values")
            if set(actual_ids) != set(expected_ids):
                missing = sorted(set(expected_ids) - set(actual_ids))
                extra = sorted(set(actual_ids) - set(expected_ids))
                raise ValueError(f"Batch prediction sample_id mismatch: missing={missing}, extra={extra}")
            by_id = dict(zip(actual_ids, predictions, strict=True))
            records = []
            for source, sample in zip(sources, samples, strict=True):
                prediction = by_id[sample.sample_id]
                validate_prediction_for_sample(sample, prediction)
                records.append(build_inference_record(source, self.config.infer, prediction=prediction))
            return records
        except Exception as exc:
            return [
                build_inference_record(
                    source,
                    self.config.infer,
                    error=f"{type(exc).__name__}: {exc}",
                    raw_response=getattr(exc, "raw_response", None),
                )
                for source in sources
            ]

    def _compute_record_metrics(self, records: list[EvaluationRecord], source: str | Path = "memory") -> dict:
        if not records:
            raise ValueError(f"No successful EvaluationRecord rows found in {source}")
        if any(not record.prediction or record.prediction.status != "success" for record in records):
            raise ValueError(f"Metric input must contain only successful records: {source}")
        identities = [
            (
                (
                    record.sample.dataset_name
                    if isinstance(record.sample, ProgressSample)
                    else (record.sample.chosen_dataset_name, record.sample.rejected_dataset_name)
                ),
                record.prediction.infer_name if record.prediction else None,
                record.sample.sample_id,
            )
            for record in records
        ]
        if len(identities) != len(set(identities)):
            raise ValueError(f"Metric input contains duplicate dataset/infer/sample identities: {source}")
        for record in records:
            if record.metrics is not None and not isinstance(record.metrics, dict):
                raise ValueError("Metric writeback requires record.metrics to be a mapping or None")
        metric_names = [self.config.eval_types]
        results = compute_metrics(
            records,
            self._with_progress(
                metric_names,
                description="Stage 3/3 Compute metrics",
                unit="metric",
                total=len(metric_names),
            ),
        )
        detail_keys = _detail_keys(records)
        for record in records:
            updated = {key: value for key, value in (record.metrics or {}).items() if key not in results}
            key = detail_keys[id(record)]
            for name, result in results.items():
                details = result.get("details", {})
                if key in details:
                    updated[name] = details[key]
            if updated or record.metrics is not None:
                record.metrics = updated
        return results

    def sample(self, samples_path: str | Path | None = None) -> None:
        """Stage 1: prepare a sampler and optionally save its trajectory pool as JSONL.

        samples_path overrides the trajectory output path; existing directories use samples.jsonl.
        Results are reported through logging.
        """
        EvalConfig.model_validate(self.config, context={"samples_path": samples_path})

        save_samples = self.config.sampling.save_samples
        destination = (Path(samples_path) if samples_path is not None else self.samples_path) if save_samples else None
        if destination is not None and destination.is_dir():
            destination = destination / "samples.jsonl"
        logger.info("Stage 1 Sample started: %s", destination or "prepare sampler")
        self.sampler = SAMPLERS.get(self.config.eval_types)(self.config.sampling)

        if destination is None:
            logger.info(
                "Stage 1/3 Sampler prepared: %d trajectories; samples generated during infer", self.sampler.pool_size
            )
            return
        # 如果不保存.npz,程序到这里已经结束了
        # 如果保存.npz,程序会继续执行到这里,将采样结果保存到指定路径
        save_trajectories(
            self._with_progress(
                self.sampler.pool,
                description="Stage 1/3 Save trajectories",
                unit="trajectory",
            ),
            destination,
        )
        logger.info("Stage 1/3 Saved %d trajectories to %s", self.sampler.pool_size, destination)

    def infer(
        self,
        *,
        predictions_path: str | Path | None = None,
    ) -> tuple[dict, list[EvaluationRecord]]:
        """Stage 2: infer samples generated by the prepared sampler."""
        if predictions_path is not None and self.output_dir is None:
            raise ValueError("predictions_path requires output_dir")
        if self.sampler is None:
            raise ValueError("infer() requires a prepared sampler; call sample() first")
        inputs = self.sampler.sample()

        load_builtin_infer(self.config.infer.name)
        infer_cls = INFERS.get(self.config.infer.name)
        required = {"preference" if self.sampler.eval_type == "quality_preference" else "progress"}
        unsupported = required - infer_cls.capabilities
        if unsupported:
            raise ValueError(f"Infer '{self.config.infer.name}' does not support: {', '.join(sorted(unsupported))}")

        if predictions_path is not None:
            destination = Path(predictions_path)
            if destination != self.predictions_path:
                self.predictions_path = destination
                self.errors_path = destination.with_name(f"{destination.stem}.errors.jsonl")
        # 加载断点信息, 自动跳过已经成功的记录
        checkpoint: dict[str, EvaluationRecord] = {}
        if self.output_dir is not None:
            prepare_inference_outputs(self.predictions_path, self.errors_path, resume=self.config.resume)
            for row in read_jsonl(self.predictions_path):
                record = EvaluationRecord.model_validate(row)
                checkpoint[record.sample.sample_id] = record
        pending = self._with_progress(
            inputs,
            description="Stage 2/3 Infer",
            unit="sample",
            total=self.sampler.pool_size,
        )

        logger.info("Stage 2/3 Infer started: sampler")
        successful: dict[str, EvaluationRecord] = {}
        failed_ids: set[str] = set()
        seen: set[str] = set()
        input_order: list[str] = []
        executed = skipped = 0
        infer = None
        for source_batch in batched(pending, self.config.infer.batch_size):
            runtime_sources: list[EvaluationRecord] = []
            runtime_samples: list[EvaluationSample] = []
            batch_records: list[EvaluationRecord] = []
            # 准备当前batch的模型输入
            for item in source_batch:
                sample_id = item.sample_id
                if sample_id in seen:
                    raise ValueError(f"Duplicate sample_id: {sample_id}")
                seen.add(sample_id)
                input_order.append(sample_id)
                if sample_id in checkpoint:
                    successful[sample_id] = checkpoint[sample_id]
                    skipped += 1
                    continue
                source_record = clear_non_string_frame_values(
                    EvaluationRecord(eval_type=self.sampler.eval_type, sample=item)
                )
                runtime_sources.append(source_record)
                runtime_samples.append(item)
            if runtime_samples:
                if infer is None:
                    infer = infer_cls(self.config.infer)
                batch_records.extend(self._run_inference_batch(infer, runtime_sources, runtime_samples))
            executed += len(batch_records)
            for record in batch_records:
                if record.prediction.status == "success":
                    successful[record.sample.sample_id] = record
                else:
                    failed_ids.add(record.sample.sample_id)
                    logger.warning("Inference failed for %s: %s", record.sample.sample_id, record.prediction.error)
            if self.output_dir is not None:
                append_inference_records(batch_records, self.predictions_path, self.errors_path)
            del runtime_samples, runtime_sources, source_batch, item
        if not seen:
            raise ValueError(f"Sampling produced no samples for eval types: {self.config.eval_types}")
        summary = {
            "coverage": self._build_coverage_summary(
                successful_ids=set(successful),
                failed_ids=failed_ids,
                total=len(seen),
                executed=executed,
                skipped=skipped,
            ),
            "samples": None,
            "predictions": str(self.predictions_path) if self.predictions_path is not None else None,
            "errors": str(self.errors_path) if self.errors_path is not None else None,
        }
        records = [successful[sample_id] for sample_id in input_order if sample_id in successful]
        logger.info(
            "Stage 2/3 Infer completed: %d successful, %d failed, %d executed, %d skipped",
            summary["coverage"]["successful"],
            summary["coverage"]["failed"],
            summary["coverage"]["executed"],
            summary["coverage"]["skipped"],
        )
        return summary, records

    def evaluate_metrics(
        self,
        predictions_path: str | Path | None = None,
        *,
        records: list[EvaluationRecord] | None = None,
        coverage: dict[str, int] | None = None,
    ) -> dict:
        """Stage 3: compute metrics from supplied records or a prediction file.

        Without explicit input, read the configured prediction file. In-memory
        inference results and their coverage must be passed by the caller.
        """
        if predictions_path is not None and records is not None:
            raise ValueError("Provide either predictions_path or records, not both")
        source = Path(predictions_path) if predictions_path is not None else None
        if source is None and records is None:
            source = self.predictions_path
            if source is None:
                raise ValueError("evaluate_metrics() requires predictions_path or records")
        if source is not None:
            if not source.is_file():
                raise FileNotFoundError(f"Prediction artifact not found: {source}")
            records = [EvaluationRecord.model_validate(row) for row in read_jsonl(source)]
        if coverage is None:
            successful_ids = {record.sample.sample_id for record in records}
            failed = (
                len({row["sample"]["sample_id"] for row in read_jsonl(self.errors_path)} - successful_ids)
                if source is not None and source == self.predictions_path and self.errors_path is not None
                else 0
            )
            coverage = {
                "total": len(records) + failed,
                "successful": len(records),
                "failed": failed,
                "executed": 0,
                "skipped": 0,
            }
        logger.info("Stage 3/3 Metrics started: %s", source or "memory")
        if not records and coverage["successful"] == 0 and coverage["failed"] > 0:
            metrics = {}
        else:
            metrics = self._compute_record_metrics(records, source or "memory")
        summary = {
            "metrics": metrics,
            "coverage": coverage,
            "predictions": str(source) if source is not None else None,
            "details": str(self.metrics_detail_path) if self.metrics_detail_path is not None else None,
        }
        if self.output_dir is not None:
            summary_metrics = {
                name: {key: value for key, value in result.items() if key not in {"details", "task_details"}}
                for name, result in metrics.items()
            }
            self.metrics_path.parent.mkdir(parents=True, exist_ok=True)
            self.metrics_path.write_text(
                json.dumps({**summary, "metrics": summary_metrics}, indent=2, ensure_ascii=False), encoding="utf-8"
            )
            write_metric_details_jsonl(self.metrics_detail_path, records, metrics)
        logger.info("Stage 3/3 Metrics completed: %d metrics from %d predictions", len(metrics), len(records))
        return summary

    def run(self) -> dict:
        """Convenience orchestration for stage 1 -> stage 2 -> stage 3."""
        self.sample()
        summary, records = self.infer()
        return self.evaluate_metrics(records=records, coverage=summary["coverage"])
