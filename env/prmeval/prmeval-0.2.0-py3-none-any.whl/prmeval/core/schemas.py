"""评估数据结构及记录状态约束。"""

from __future__ import annotations

from typing import Annotated, Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


class FrameworkModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class Trajectory(FrameworkModel):
    id: str
    task: str
    frames: Any
    data_source: str = "unknown"
    is_robot: bool = False
    is_simulation: bool = False
    quality_label: str | None = None
    partial_success: float | None = None
    preference_group_id: str | None = None
    preference_rank: int | float | None = None
    target_progress: list[float] | None = None
    frame_indices: list[int] | None = None
    num_frames_total: int | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class EvaluationSample(FrameworkModel):
    sample_id: str


class ProgressSample(EvaluationSample):
    dataset_name: str
    trajectory: Trajectory


class PreferenceSample(EvaluationSample):
    chosen_dataset_name: str
    rejected_dataset_name: str
    chosen_trajectory: Trajectory
    rejected_trajectory: Trajectory


class FrameReference(FrameworkModel):
    """Portable reference to a materialized frame array in a sample bundle."""

    type: Literal["npz"] = "npz"
    path: str
    key: str = "frames"
    num_frames: int = Field(ge=1)
    sha256: str = Field(min_length=64, max_length=64)


class Prediction(FrameworkModel):
    sample_id: str
    status: Literal["success", "error"]
    infer_name: str = Field(description="Registered infer implementation used for this execution")
    model: str | None = Field(default=None, description="Actual model on success, attempted model on failure")
    error: str | None = None
    raw_response: Any = Field(default=None, description="Unparsed backend response retained when inference fails")

    @model_validator(mode="after")
    def validate_status(self) -> Prediction:
        if self.status == "error":
            if not self.error or not self.error.strip():
                raise ValueError("An error prediction requires a non-empty error message")
        elif self.error is not None or self.raw_response is not None:
            raise ValueError("A successful prediction cannot contain error or raw_response")
        return self


class ProgressPrediction(Prediction):
    progress: list[Annotated[float, Field(ge=0, le=1)]] = Field(min_length=1)


class PreferencePrediction(Prediction):
    chosen_probability: float = Field(ge=0, le=1)
    preference: Literal["chosen", "rejected", "tie"]


class EvaluationRecord(FrameworkModel):
    """A sampled request, its optional inference result, and per-record metrics."""

    eval_type: str
    sample: EvaluationSample
    prediction: ProgressPrediction | PreferencePrediction | Prediction | None = None
    metrics: Any | None = None

    @model_validator(mode="after")
    def validate_prediction(self) -> EvaluationRecord:
        if self.prediction is None:
            return self
        if self.prediction.sample_id != self.sample.sample_id:
            raise ValueError("Prediction sample_id must match sample.sample_id")
        if self.prediction.status == "success":
            expected = ProgressPrediction if isinstance(self.sample, ProgressSample) else PreferencePrediction
            if not isinstance(self.prediction, expected):
                raise ValueError(f"{type(self.sample).__name__} requires {expected.__name__}")
        elif type(self.prediction) is not Prediction:
            raise ValueError("An error record requires Prediction without success payload fields")
        return self
