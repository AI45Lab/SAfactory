# RayJob SDK

This is an SDK for interacting with the RayJob API.

## Installation

You can install this SDK using `pip`:

```bash
pip install .  or pip install -e .
```

### 使用

例子： `example/all.py`

接口说明： `rayjob_sdk/rayjob.py`