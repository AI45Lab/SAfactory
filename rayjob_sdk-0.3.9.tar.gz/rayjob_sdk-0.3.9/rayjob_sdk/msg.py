
from dataclasses import dataclass, field
from dataclasses_json import dataclass_json
from enum import Enum
from typing import List, Optional, Dict, Any, Generic, TypeVar

@dataclass_json
@dataclass
class TypeMeta:
    kind: Optional[str] = None
    apiVersion: Optional[str] = None

@dataclass_json
@dataclass
class ObjectMeta:
    name: Optional[str] = None
    generateName: Optional[str] = None
    namespace: Optional[str] = None
    uid: Optional[str] = None
    resourceVersion: Optional[str] = None
    creationTimestamp: Optional[str] = None  # 
    deletionTimestamp: Optional[str] = None  # 
    labels: Dict[str, str] = field(default_factory=dict)
    annotations: Dict[str, str] = field(default_factory=dict)


@dataclass_json
@dataclass
class HeadGroupSpec:
    template: Dict[str, Any] = field(default_factory=dict)
    headService: Dict[str, Any] = field(default_factory=dict)
    enableIngress: Optional[bool] = None
    rayStartParams: Dict[str, str] = field(default_factory=dict)
    serviceType: Optional[str] = None

@dataclass_json
@dataclass
class WorkerGroupSpec:
    suspend: Optional[bool] = None
    groupName: str = ""
    replicas: int = 0
    minReplicas: int = 0
    maxReplicas: int = 2147483647
    idleTimeoutSeconds: Optional[int] = None
    rayStartParams: Dict[str, str] = field(default_factory=dict)
    template: Dict[str, Any] = field(default_factory=dict)
    scaleStrategy: Dict[str, Any] = field(default_factory=dict)
    numOfHosts: int = 1

@dataclass_json
@dataclass
class RayClusterSpec:
    suspend: Optional[bool] = None
    managedBy: Optional[str] = None
    autoscalerOptions: Optional[Dict[str, Any]] = None
    headServiceAnnotations: Dict[str, str] = field(default_factory=dict)
    enableInTreeAutoscaling: Optional[bool] = None
    gcsFaultToleranceOptions: Optional[Dict[str, Any]] = None
    headGroupSpec: HeadGroupSpec = field(default_factory=HeadGroupSpec)
    rayVersion: str = ""
    WorkerGroupSpecs: List[WorkerGroupSpec] = field(default_factory=list)

class ClusterState(str, Enum):
    Ready       = ""
    Failed      = "PENDING"
    Suspended   = "RUNNING"

@dataclass_json
@dataclass
class HeadInfo:
    podIP: str = ""
    serviceIP: str = ""
    podName: str = ""
    serviceName: str = ""

@dataclass_json
@dataclass
class RayClusterStatus:
    state: ClusterState = ClusterState.Ready
    desiredCPU: Any = None
    desiredMemory: Any = None
    desiredGPU: Any = None
    desiredTPU: Any = None
    lastUpdateTime: Optional[str] = None
    stateTransitionTimes: Dict[ClusterState, str] = field(default_factory=dict)
    endpoints: Dict[str, str] = field(default_factory=dict)
    head: HeadInfo = field(default_factory=HeadInfo)
    reason: str = ""
    conditions: List[Dict[str, Any]] = field(default_factory=list)
    readyWorkerReplicas: int = 0
    availableWorkerReplicas: int = 0
    desiredWorkerReplicas: int = 0
    minWorkerReplicas: int = 0
    maxWorkerReplicas: int = 0
    observedGeneration: int = 0

@dataclass_json
@dataclass
class RayJobSpec:
    activeDeadlineSeconds: Optional[int] = None
    backoffLimit: int = 0
    rayClusterSpec: RayClusterSpec = field(default_factory=RayClusterSpec)
    submitterPodTemplate: Optional[Dict[str, Any]] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    clusterSelector: Dict[str, str] = field(default_factory=dict)
    submitterConfig: Optional[Dict[str, Any]] = None
    managedBy: Optional[str] = None
    deletionPolicy: Optional[str] = None
    entrypoint: Optional[str] = None
    runtimeEnvYAML: Optional[str] = None
    jobId: Optional[str] = None
    submissionMode: str = "K8sJobMode"
    entrypointResources: Optional[str] = None
    entrypointNumCpus: Optional[float] = None
    entrypointNumGpus: Optional[float] = None
    ttlSecondsAfterFinished: int = 0
    shutdownAfterJobFinishes: Optional[bool] = None
    suspend: Optional[bool] = None

class JobStatus(str, Enum):
    JobStatusNew        = ""
    JobStatusPending    = "PENDING"
    JobStatusRunning    = "RUNNING"
    JobStatusStopped    = "STOPPED"
    JobStatusSucceeded  = "SUCCEEDED"
    JobStatusFailed     = "FAILED"

class JobDeploymentStatus(str, Enum):
    JobDeploymentStatusNew           = ""
    JobDeploymentStatusInitializing  = "Initializing"
    JobDeploymentStatusRunning       = "Running"
    JobDeploymentStatusComplete      = "Complete"
    JobDeploymentStatusFailed        = "Failed"
    JobDeploymentStatusSuspending    = "Suspending"
    JobDeploymentStatusSuspended     = "Suspended"
    JobDeploymentStatusRetrying      = "Retrying"
    JobDeploymentStatusWaiting       = "Waiting"

@dataclass_json
@dataclass
class RayJobStatus: 
    rayJobInfo: Dict[str, Any] = field(default_factory=dict)
    jobId: str = ""
    rayClusterName: str = ""
    dashboardURL: str = ""
    jobStatus: JobStatus = JobStatus.JobStatusNew
    jobDeploymentStatus: JobDeploymentStatus = JobDeploymentStatus.JobDeploymentStatusNew
    reason: str = ""
    message: str = ""
    startTime: Optional[str] = None  
    endTime: Optional[str] = None    
    succeeded: Optional[int] = 0
    failed: Optional[int] = 0
    rayClusterStatus: RayClusterStatus = field(default_factory=RayClusterStatus)
    observedGeneration: int = 0

@dataclass_json
@dataclass
class RayJob(TypeMeta):
    metadata: ObjectMeta = field(default_factory=ObjectMeta)
    spec: RayJobSpec = field(default_factory=RayJobSpec)
    status: RayJobStatus = field(default_factory=RayJobStatus)

T = TypeVar('listresult')

@dataclass_json
@dataclass
class ListResult(Generic[T]):
    total: int
    data: List[T] = field(default_factory=list)
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass_json
@dataclass
class ResourcesSummary:
    cpu: str = "0"
    memory: str = "0"
    gpu: Optional[str] = None
    nvidia_com_gpu: Optional[str] = field(default=None, metadata={"json_key": "nvidia.com/gpu"})


@dataclass_json
@dataclass
class RayJobSummary:
    id: str = ""
    jobName: str = ""
    displayName: str = ""
    quotaGroup: str = ""
    status: JobDeploymentStatus = JobDeploymentStatus.JobDeploymentStatusNew
    rayClusterStatus: str = ""
    resources: ResourcesSummary = field(default_factory=ResourcesSummary)
    createdAt: str = ""
    startTime: Optional[str] = None
    endTime: Optional[str] = None
    creator: str = ""
    creatorId: str = ""

@dataclass_json
@dataclass
class ListRayJobSummary:
    total: int
    data: List[RayJobSummary] = field(default_factory=list)
    extra: Dict[str, Any] = field(default_factory=dict)

@dataclass_json
@dataclass
class Replica:
    id: str = ""
    groupType: str = ""
    groupName: str = ""
    status: str = ""
    podIP: str = ""
    podName: str = ""
    nodeIP: str = ""
    resources: Dict[str, Any] = field(default_factory=dict)
    createdAt: str = ""

@dataclass_json
@dataclass
class Volume:
    fsType: str = ""
    endpoint: str = ""
    containerPath: str = ""

@dataclass_json
@dataclass
class HeadConfig:
    resources: Dict[str, Any] = field(default_factory=dict)
    headEnv: Optional[Dict[str, str]] = None

@dataclass_json
@dataclass
class WorkerGroupConfig:
    groupName: str = ""
    positiveTags: Optional[List[str]] = None
    negativeTags: Optional[List[str]] = None
    privateMachine: Optional[str] = None
    localStorage: Optional[str] = None
    replicas: int = 0
    maxReplicas: Optional[int] = None
    minReplicas: Optional[int] = None
    resources: Dict[str, Any] = field(default_factory=dict)
    rayStartParams: Optional[Dict[str, str]] = None
    enableAutoscaling: Optional[bool] = None
    env: Optional[Dict[str, str]] = None
    labels: Optional[Dict[str, str]] = None
    annotations: Optional[Dict[str, str]] = None

@dataclass_json
@dataclass
class RaylinkRayJobSpec:
    jobName: str = ""
    displayName: str = ""
    description: str = ""
    creatorid: Optional[str] = None
    creatorName: Optional[str] = None
    quotagroup: str = ""
    privateMachine: Optional[str] = None

    image: Optional[str] = None
    rayVersion: Optional[str] = None
    entrypoint: Optional[str] = None

    env: Optional[Dict[str, str]] = None
    volumes : Optional[List[Volume]] = None

    headSpec: HeadConfig = field(default_factory=HeadConfig)
    workerGroups: List[WorkerGroupConfig] = field(default_factory=list)
    ttlSecondsAfterFinished: Optional[int] = None
    backoffLimit: Optional[int] = None
    activeDeadlineSeconds: Optional[int] = None
    deletionPolicy: Optional[str] = None
    jobMode: Optional[str] = None  # K8sJobMode | SidecarMode

@dataclass_json
@dataclass
class RayJobDetail(RaylinkRayJobSpec):
    id: str = ""
    resources: ResourcesSummary = field(default_factory=ResourcesSummary)
    rayClusterName: str = ""
    rayClusterStatus: str = ""
    status: JobDeploymentStatus = JobDeploymentStatus.JobDeploymentStatusNew
    createdAt: str = ""
    startTime: Optional[str] = None
    endTime: Optional[str] = None
    replicas: Optional[List[Replica]] = None

@dataclass_json
@dataclass
class ContainerInfo:
    name: str = ""
    image: str = ""
    state: str = ""
    ready: bool = False
    restartCount: int = 0
    startedAt: Optional[str] = None

@dataclass_json
@dataclass
class PodCondition:
    type: str = ""
    status: str = ""
    lastTransitionTime: Optional[str] = None

@dataclass_json
@dataclass
class PodEvent:
    type: str = ""
    reason: str = ""
    message: str = ""
    firstTimestamp: Optional[str] = None
    lastTimestamp: Optional[str] = None
    count: int = 0

@dataclass_json
@dataclass
class PodDetailInfo:
    id: str = ""
    podName: str = ""
    status: str = ""
    phase: str = ""
    groupType: str = ""
    groupName: str = ""
    podIP: str = ""
    nodeIP: str = ""
    nodeName: str = ""
    hostIP: str = ""
    resources: Dict[str, Any] = field(default_factory=dict)
    resourceUsage: Dict[str, Any] = field(default_factory=dict)
    createdAt: str = ""
    startTime: Optional[str] = None
    restartCount: int = 0
    ready: bool = False
    containers: Optional[List[ContainerInfo]] = None
    conditions: Optional[List[PodCondition]] = None
    events: Optional[List[PodEvent]] = None

@dataclass_json
@dataclass
class ListPodDetailInfo:
    total: int = 0
    data: Optional[List[PodDetailInfo]] = None
