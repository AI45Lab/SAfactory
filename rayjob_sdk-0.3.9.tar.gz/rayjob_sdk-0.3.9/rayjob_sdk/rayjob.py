from typing import Any, Dict, Optional, Union, List
from enum import Enum
import os
from rayjob_sdk.utils import HTTPClient, extract_data, SDKException
from rayjob_sdk.msg import RayJob, JobStatus, ListRayJobSummary, \
    RayJobSummary,RayJobDetail,PodDetailInfo,ListPodDetailInfo,RaylinkRayJobSpec, \
    HeadConfig, WorkerGroupConfig,Volume
import requests
from dataclasses import asdict

def join_url(base: str, *paths: str) -> str:
    return "/".join([base.rstrip("/")] +[ p.lstrip("/") for p in paths])


def split_tenant_from_project(name: str) -> str:
    return name.split("-", 1)[0]

class SortOrder(str, Enum):
    ASC = "asc"
    DESC = "desc"

class RayJobClient:
    _RAYJOB_BASE_URL = "/kapi/ray.brainpp.cn/v1"

    def __init__(
        self,
        domain: Optional[str] = None,
        tenant: Optional[str] = None,
        access_key: Optional[str] = None,
        secret_key: Optional[str] = None,
        token: Optional[str] = None,
        timeout: int = 30,
        verify: bool = True,
    ) -> None:
        """
        初始化 RayJob 客户端实例。

        Args:
            domain (Optional[str]):  平台域名，eg: x86test.shahizuan.com， 如果未提供则假设在开发机环境内尝试自动读取 。
            tenant (Optional[str]): 当前操作所属的租户名称， 如果未提供则假设在开发机环境内尝试自动读取。
            access_key (Optional[str]): 访问密钥，如果未提供则假设在开发机环境内尝试自动读取。
            secret_key (Optional[str]): 密钥的配对值，如果未提供则假设在开发机环境尝试自动读取。
            token (Optional[str]): 提供浏览器端token,当access/secret key未提供且不在开发机内时。
            timeout (int): HTTP 请求超时时间（单位：秒）。默认 30。
            verify (bool): 是否验证 SSL 证书。默认 True。

        Returns:
            None

        Raises:
            ValueError: 当必要的认证参数缺失或配置错误时抛出。
        """
        self.domain = domain or os.getenv("KUBEBRAIN_CLUSTER_ENTRY")
        if self.domain is None:
            raise ValueError("Domain must be provided either as an argument or in the KUBEBRAIN_CLUSTER_ENTRY environment variable.")
        
        self.tenant = tenant
        self.project = None
        if self.tenant is None:
            self.project = os.getenv("KUBEBRAIN_WORKSPACE_NAMESPACE")
            if self.project is None:
                raise ValueError("Tenant must be provided either as an argument or in the KUBEBRAIN_WORKSPACE_NAMESPACE environment variable.")
            else:
                self.tenant = split_tenant_from_project(self.project)

        if not access_key or not secret_key:
            if os.path.exists("/.auth/accesskey_id") and os.path.exists("/.auth/accesskey_secret"):
                with open("/.auth/accesskey_id") as f:
                    access_key = f.read().strip()
                with open("/.auth/accesskey_secret") as f:
                    secret_key = f.read().strip()

        if (not access_key or not secret_key) and not token:
            raise ValueError("Access key and secret key must be provided either as arguments or in the specified files, or a token must be provided.")

        self._http_client = HTTPClient(
                access_key = access_key,
                secret_key = secret_key,
                token = token,
                base_url = join_url(self.domain, self._RAYJOB_BASE_URL),
                timeout = timeout,
                verify = verify
            )
    
    def _resolve_tenant_project(self, tenant, project):
        tenant = tenant or self.tenant
        project = project or self.project

        if not tenant:
            raise ValueError("tenant must be provided")
        if not project:
            raise ValueError("project must be provided")

        return tenant, project
    
    @extract_data(RayJob)
    def create(self,
               name: str,
               image: str,
               entrypoint: str,

               quotagroup: str,
               description: Optional[str] = None,

               rayVersion: Optional[str] = None,
               headConfg: Optional[HeadConfig] = None,
               workerGroupConfig: Optional[List[WorkerGroupConfig]] = None,
               env:  Optional[Dict[str, str]] = None,
               volumes : Optional[List[Volume]] = None,

               ttlSecondsAfterFinished: Optional[int] = None,
               backoffLimit: Optional[int] = None,
               activeDeadlineSeconds: Optional[int] = None,
               jobMode: str = "K8sJobMode",

               privateMachine: Optional[str] = None,

               tenant: Optional[str] = None,
               project: Optional[str] = None,
               ) -> requests.Response:
        """
        创建job规格的 RayJob.

        Args:
            name (str): RayJob 名称。
            image (str): 执行任务的容器镜像,需要为完整的路径 eg:registry.x86test.shzhisuan.com/library/ray:2.49.2。
            entrypoint (str): 任务入口命令,eg:sleep 3600。
            quotagroup (str): 任务所属配额组，用于资源隔离与调度。
            description (Optional[str]): 任务描述信息，默认 None。
            rayVersion (Optional[str]): 指定 Ray 版本号，默认 None。
            headConfg (Optional[HeadConfig]): Ray 集群 Head 节点配置。
            workerGroupConfig (Optional[List[WorkerGroupConfig]]): Worker 节点组配置列表。
            env (Optional[Dict[str, str]]): 任务环境变量（键值对形式）。
            volumes (Optional[List[Volume]]): 挂载卷配置，用于数据持久化。
            ttlSecondsAfterFinished (Optional[int]): 任务结束后保留的秒数。
            backoffLimit (Optional[int]): 任务失败时的最大重试次数。
            activeDeadlineSeconds (Optional[int]): 任务最长运行时限（秒）。
            jobMode (str): 作业执行模式，默认 "K8sJobMode"。
            privateMachine (Optional[str]): RayJob级别的私有机器调度标识，可选值: "yes", "no"。
            tenant (Optional[str]): 所属租户标识。
            project (Optional[str]): 所属项目标识。

        Returns:
            requests.Response: Raw HTTP response object.
            After being processed by @extract_data, the actual return type 
            becomes a `RayJob` instance.

        Raises:
            ValueError: If `name` is not provided.
            HTTPError: If the HTTP request fails (4xx/5xx).
            SDKException: For SDK-specific errors.
        """
        tenant, project = self._resolve_tenant_project(tenant, project)

        endpoint = f"/tenants/{tenant}/projects/{project}/rayjobs"
        spec = RaylinkRayJobSpec(
            jobName=name,
            image=image,
            entrypoint=entrypoint,
            quotagroup=quotagroup,
            description=description,
            privateMachine=privateMachine,
            rayVersion=rayVersion,
            headSpec=headConfg,
            workerGroups=workerGroupConfig,
            env=env or {},
            volumes=volumes or [],
            ttlSecondsAfterFinished=ttlSecondsAfterFinished,
            backoffLimit=backoffLimit,
            activeDeadlineSeconds=activeDeadlineSeconds,
            jobMode=jobMode,
        )
        return self._http_client.post(endpoint, json_data=asdict(spec))

    @extract_data(RayJobDetail)
    def get(self, 
            name: str,
            tenant: Optional[str] = None, 
            project: Optional[str] = None,
            ) -> requests.Response:
        """
        获取指定的 RayJob 详情.

        Args:
            name (str): RayJob name to retrieve.
            tenant (Optional[str]): Tenant name. If None, use default from client config.
            project (Optional[str]): Project name. If None, use default from client config.

        Returns:
            requests.Response: Raw HTTP response object.
            After being processed by @extract_data, the actual return type 
            becomes a `RayJobDetail` instance.

        Raises:
            ValueError: If `name` is not provided.
            HTTPError: If the HTTP request fails (4xx/5xx).
            SDKException: For SDK-specific errors.
        """
        if not name:
            raise ValueError("name must be provided")
        
        tenant, project = self._resolve_tenant_project(tenant, project)

        endpoint = f"/tenants/{tenant}/projects/{project}/rayjobs/{name}"
        return self._http_client.get(endpoint)

    @extract_data(ListPodDetailInfo)
    def replicas(self, 
            name: str,
            tenant: Optional[str] = None, 
            project: Optional[str] = None,
            page: Optional[int] = 1,
            pageSize: Optional[int] = 10,
            labelSelector: Optional[str] = None,
            keywords: Optional[str] = None,
            ) -> requests.Response:
        """
        获取指定的 RayJob 的pod实例.

        Args:
            tenant (Optional[str]): Tenant name. If None, use default from client config.
            project (Optional[str]): Project name. If None, use default from client config.
            name (Optional[str]): RayJob name to retrieve.
            keywords (Optional[str], default=""): search keyword for pod name, node name, pod ip.
            page (Optional[int], default=1): Page number (starts from 1).
            pageSize (Optional[int], default=10): Items per page.
            labelSelector (Optional[str]): label selector to filter pods.
        Returns:
            requests.Response: Raw HTTP response object.
            After being processed by @extract_data, the actual return type 
            becomes a `ListPodDetailInfo` instance.

        Raises:
            ValueError: If `name` is not provided.
            SDKException: For SDK-specific errors.
        """
        if not name:
            raise ValueError("name must be provided")
        
        tenant, project = self._resolve_tenant_project(tenant, project)

        endpoint = f"/tenants/{tenant}/projects/{project}/rayjobs/{name}/replicas"
        params = {k: v for k, v in {
            "keywords": keywords,
            "page": page,
            "pageSize": pageSize,
            "labelSelector": labelSelector,
        }.items() if v is not None}

        return self._http_client.get(endpoint, params=params)
    
    @extract_data(ListRayJobSummary)
    def list(self, 
             tenant: Optional[str] = None, 
             project: Optional[str] = None, 
             keywords: Optional[str] = "",
             page: Optional[int] = 1,
             pageSize: Optional[int] = 10,
             sortBy: Optional[str] = "creationTimestamp",
             sortOrder: Optional[SortOrder] = SortOrder.DESC,
             creatorId: Optional[str] = None,
             status: Optional[JobStatus] = None,
             quotagroup: Optional[str] = None,
             all : Optional[Union[bool, str]] = "true") -> requests.Response:
        """
        获取rayjob列表.

        Args:
            tenant (Optional[str]): Tenant name. If None, use default from client.
            project (Optional[str]): Project name. If None, use default from client.
            keywords (Optional[str], default=""): search keyword.
            page (Optional[int], default=1): Page number (starts from 1).
            pageSize (Optional[int], default=10): Items per page.
            sortBy (Optional[str], default="creationTimestamp"): Sort field.
            sortOrder (Optional[SortOrder], default=SortOrder.DESC): Sort order.
            creatorId (Optional[str]): Filter by creator ID.
            status (Optional[JobStatus]): Filter by job status.
            quotagroup (Optional[str]): Filter by quota group.
            all (Optional[Union[bool, str]], default="true"):
                Whether to return all results (string "true"/"false" or boolean).
                when you are manager, all=true means list all rayjobs in the project not only yours.

        Returns:
            requests.Response: Raw HTTP response object,
            but after @extract_data, actual return is ListResult[RayJobSummary].

        Raises:
            HTTPError: If the HTTP request fails.
            ValueError: If parameters are invalid.
            SDKException: For SDK-specific errors.
        """
        tenant, project = self._resolve_tenant_project(tenant, project)

        endpoint = f"/tenants/{tenant}/projects/{project}/rayjobs"
        params = {k: v for k, v in {
            "keywords": keywords,
            "page": page,
            "pageSize": pageSize,
            "sortBy": sortBy,
            "sortOrder": sortOrder,
            "creatorId": creatorId,
            "status": status,
            "quotagroup": quotagroup,
            "all": all
        }.items() if v is not None}

        return self._http_client.get(endpoint, params=params)
              
    @extract_data(bool)
    def stop(self, 
               name: str,
               tenant: Optional[str] = None, 
               project: Optional[str] = None,
               force: Optional[bool] = None,
            ) -> requests.Response:
        """
        停止指定的 RayJob

        Args:
            tenant (Optional[str]): Tenant name. If None, use default from client config.
            project (Optional[str]): Project name. If None, use default from client config.
            name (Optional[str]): RayJob name to stop.
            force (Optional[bool]): Whether to force stop the job.
        Returns:
            bool: True if deletion was successful.

        Raises:
            ValueError: If `name` is not provided.
            SDKException: For SDK-specific errors.
        """
        if not name:
            raise ValueError("name must be provided")
        
        tenant, project = self._resolve_tenant_project(tenant, project)

        endpoint = f"/tenants/{tenant}/projects/{project}/rayjobs/{name}/stop"

        params = {k: v for k, v in {
            "force": force,
        }.items() if v is not None}

        return self._http_client.patch(endpoint, params=params)

    @extract_data(bool)
    def delete(self, 
               name: str,
               tenant: Optional[str] = None, 
               project: Optional[str] = None,
            ) -> requests.Response:
        """
        删除指定的 RayJob，该name指定的任务应该是停止状态.

        Args:
            tenant (Optional[str]): Tenant name. If None, use default from client config.
            project (Optional[str]): Project name. If None, use default from client config.
            name (Optional[str]): RayJob name to delete.
        Returns:
            bool: True if deletion was successful.

        Raises:
            ValueError: If `name` is not provided.
            SDKException: For SDK-specific errors.
        """
        if not name:
            raise ValueError("name must be provided")
        
        tenant, project = self._resolve_tenant_project(tenant, project)

        endpoint = f"/tenants/{tenant}/projects/{project}/rayjobs/{name}"

        return self._http_client.delete(endpoint)


if __name__ == "__main__":
    import sys
    import random
    import time

    domain = "https://x86test.shzhisuan.com"
    ak = None # "b2abf62022fd44a8fad1ee9771c34f01"
    sk = None # "059903bde1cbfa628e6caaecd8e6b5be"
    token = "eyJhbGciOiJSUzI1NiIsImtpZCI6IjRkOTNjMzkwLTM3NGUtNDRkZC1iZTU1LWNjOTc3ZTRiYmIwNCJ9.eyJpc3MiOiJodHRwczovL3g4NnRlc3Quc2h6aGlzdWFuLmNvbS9rYXBpL2F1dGgiLCJhdWQiOiJrdWJlYnJhaW4iLCJub25jZSI6IiIsImF0X2hhc2giOiJfZzhHR1d3RF9YOXBQQkJTeU5xZjdRIiwiZXhwIjoxNzYyNTQyNDMyLCJpYXQiOjE3NjI0Nzc2MzIsInN1YiI6ImU4Y2U1YjhhMTRlNjNmNWRmN2Q0YmJhZGJlODQxOGNlIiwibmFtZSI6ImFkbWluIiwicHJlZmVycmVkX3VzZXJuYW1lIjoiYWRtaW4iLCJlbWFpbCI6ImFkbWluQHRlc3QuY29tIiwic2NvcGUiOiIveDg2dGVzdC8iLCJ0ZW5hbnQiOiJ4ODZ0ZXN0IiwiYXV0aCI6Ing4NnRlc3QiLCJzdWJfdGVuYW50IjoieDg2dGVzdCIsImV4dGVybmFsX2lkIjoiZWE4MjQ0MzAtNDEyMi00N2MxLTkwYWYtN2U4NWU2ODI5N2JkIiwiZ3JvdXBzIjpudWxsLCJwaG9uZSI6IiIsInN0YXR1cyI6IiIsImF1dGhfZGF0YSI6IiJ9.celfA93cI0iE6yHZ9Rld9MHwbDX5r2iMb5tNaLtli1dB0kYnX2q4DEye9OjvfMF2jX-zzw4rSqLhCrDCxx125aOD5jX0jX2bAqje9U468L6inFQgclt4x3G48Z0dvURwYMPJKa_U7fxlDquN4Q35nyicRL_Z9lV7l1BXQM-2wYVSHgnavrLttm-eSiEWmAD5zP6FFRG8dLR_zjdEYpdvWdwaJh1LBJR0f3aO74UbUHFTpRuEX_e6yO66MrS6uVgRLHy0Z1ryDZ35o2Wu0-8oTViMivSSqoVUc55VQYthNt-r_yVDk2_G_2-vH1uZblM7x-0z6kBjhaUhHy1xVlrUIA"
    tenant = "x86test"
    project = "x86test-infra"    
    client = RayJobClient(domain=domain, tenant=tenant, access_key=ak, secret_key=sk, token=token, verify=False)

    try:
        print("\nCreating rayjob:")
        res = client.create(
            project="x86test-infra",
            name=f"sdk{random.randint(10000,99999)}",
            image="registry.x86test.shzhisuan.com/library/ray:2.49.2",
            entrypoint="sleep 3600",
            quotagroup="rayjobowner",
            description="test rayjob sdk create",
            rayVersion="2.4.9",
            headConfg=HeadConfig(
                resources= {
                    "cpu": "1",
                    "memory": "8Gi",
                    "nvidia.com/gpu": "0",
                }
            ),
            workerGroupConfig=[
                WorkerGroupConfig(
                    groupName="worker-group-1",
                    positiveTags= [],
                    negativeTags= [],
                    localStorage= "0",
                    privateMachine = "tenant",
                    replicas=1,
                    resources= {
                        "cpu": "1",
                        "memory": "8Gi",
                        "nvidia.com/gpu": "0",
                    })],
            ttlSecondsAfterFinished = 604800,
            backoffLimit = 5,
            activeDeadlineSeconds = 86400,
        )
        print("create rayjob data:", type(res), res.metadata.name)
        newname = res.metadata.name

        print("Listing rayjobs:")
        res = client.list(project=project)
        print("list data:", type(res.data[0]) if len(res.data) else None, "type item:", res.total)
        getname = ""
        for job in res.data:
            if not getname:
                getname = job.jobName
            print(" - ", type(job), job.jobName)
        
        print("\nGetting rayjob:", getname)
        res = client.get(project=project, name=getname)
        print("rayjob data:", type(res.entrypoint), res.creatorid, res.workerGroups[0].replicas)

        getname = newname
        print("\nGetting replicas:", getname)
        res = client.replicas(project=project, name=getname)
        print("replicas data:", type(res.data), "type item:", res.total)
        for pod in (item for item in res.data):
            print(" - ", type(pod), pod.id, pod.nodeName, pod.podIP)
        
        time.sleep(10)
        stopname = newname
        print("\nStopping rayjob:", stopname)
        res = client.stop(project=project, name=stopname)
        print("stop result:", res)

        delname = stopname
        print("\nDeleting rayjob:", delname)
        res = client.delete(project=project, name=delname)
        print("delete result:", res)
    except SDKException as e:
        print("failed:", e.code, e, file=sys.stderr)