
import base64
import hashlib
import hmac
import json
from typing import Dict, Any, Optional, Union
from urllib.parse import urlparse

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class HTTPClient:
    """带AK/SK鉴权的HTTP客户端"""

    def __init__(
            self,
            access_key: str,
            secret_key: str,
            token: Optional[str] = None,
            base_url: str = "https://api.example.com",
            timeout: int = 30,
            verify: bool = True,
            default_headers: Optional[Dict[str, str]] = None
    ):
        """
        初始化HTTP客户端

        Args:
            access_key: 访问密钥ID
            secret_key: 访问密钥
            base_url: API基础地址
            timeout: 请求超时时间
            default_headers: 默认请求头
        """
        self.access_key = access_key
        self.secret_key = secret_key
        self.token = token
        self.base_url = base_url.rstrip('/')
        self.timeout = timeout
        self.verify = verify
        self.session = requests.Session()

        if token:
            # 如果提供了token，则使用Bearer Token鉴权
            if not token.startswith("Bearer "):
                self.auth_header = f"Bearer {token}"
        else:
            # 生成 Basic Auth 凭证
            credentials = f"{access_key}:{secret_key}"
            encoded_credentials = base64.b64encode(credentials.encode('utf-8')).decode('utf-8')
            self.auth_header = f"Basic {encoded_credentials}"

        # 设置默认请求头
        self.default_headers = {
            "User-Agent": "ModelSetClient/1.0.0",
            "Content-Type": "application/json",
            "Authorization": self.auth_header
        }
        self.session.headers.update(self.default_headers)

    def _generate_signature(
            self,
            method: str,
            path: str,
            timestamp: str,
            body: Optional[Union[Dict, str]] = None
    ) -> str:
        """
        生成请求签名

        Args:
            method: HTTP方法
            path: 请求路径
            timestamp: 时间戳
            body: 请求体

        Returns:
            签名字符串
        """
        # 准备签名字符串
        if body is None:
            body_str = ""
        elif isinstance(body, dict):
            body_str = json.dumps(body, sort_keys=True, separators=(',', ':'))
        else:
            body_str = str(body)

        # 计算body的MD5
        body_md5 = hashlib.md5(body_str.encode('utf-8')).hexdigest()

        # 构造待签名字符串
        string_to_sign = f"{method}\n{path}\n{timestamp}\n{body_md5}"

        # 使用HMAC-SHA256生成签名
        signature = hmac.new(
            self.secret_key.encode('utf-8'),
            string_to_sign.encode('utf-8'),
            hashlib.sha256
        ).hexdigest()

        return signature

    def _build_headers(self,  custom_headers: Optional[Dict[str, str]] = None) -> Dict[str, str]:
        """
        构建请求头，包含鉴权信息

        Args:
            method: HTTP方法
            path: 请求路径
            custom_headers: 自定义请求头
            body: 请求体

        Returns:
            包含鉴权头的字典
        """
        # timestamp = str(int(time.time()))
        # signature = self._generate_signature(method, path, timestamp, body)
        #
        # # 基础鉴权头
        # auth_headers = {
        #     "X-Access-Key": self.access_key,
        #     "X-Timestamp": timestamp,
        #     "X-Signature": signature
        # }

        # 合并头信息
        headers = {**self.default_headers}
        if custom_headers:
            headers.update(custom_headers)

        return headers

    def request(
            self,
            method: str,
            endpoint: str,
            params: Optional[Dict[str, Any]] = None,
            data: Optional[Any] = None,
            json_data: Optional[Dict[str, Any]] = None,
            headers: Optional[Dict[str, str]] = None,
            **kwargs
    ) -> requests.Response:
        """
        发送HTTP请求

        Args:
            method: HTTP方法
            endpoint: API端点
            params: 查询参数
            data: 请求体数据
            json_data: JSON请求体
            headers: 自定义请求头
            **kwargs: 其他requests参数

        Returns:
            requests.Response对象
        """
        # 构建完整URL
        url = f"{self.base_url}{endpoint}"

        # 解析路径（用于签名）
        parsed_url = urlparse(url)
        path = parsed_url.path
        if parsed_url.query:
            path += f"?{parsed_url.query}"

        # 确定请求体（用于签名）
        # request_body = json_data if json_data is not None else data

        # 构建鉴权头
        auth_headers = self._build_headers(
            custom_headers=headers,
        )
        # 发送请求
        response = self.session.request(
            method=method.upper(),
            url=url,
            params=params,
            data=data,
            json=json_data,
            headers=auth_headers,
            timeout=self.timeout,
            verify=self.verify,
            **kwargs
        )
        return response

    def get_json(self, endpoint: str, **kwargs) -> Dict[str, Any]:
        """发送GET请求并返回JSON响应"""
        response = self.request("GET", endpoint, **kwargs)
        return response.json()

    def get(self, endpoint: str, **kwargs) -> requests.Response:
        """发送GET请求"""
        return self.request("GET", endpoint, **kwargs)

    def post(self, endpoint: str, **kwargs) -> requests.Response:
        """发送POST请求"""
        return self.request("POST", endpoint, **kwargs)

    def post_json(self, endpoint: str,data=None, **kwargs) -> Dict[str, Any]:
        """发送POST请求并返回JSON响应"""
        response = self.request("POST", endpoint,json_data=data, **kwargs)
        return response.json()

    def put(self, endpoint: str, **kwargs) -> requests.Response:
        """发送PUT请求"""
        return self.request("PUT", endpoint, **kwargs)

    def put_json(self, endpoint: str,data=None, **kwargs) -> Dict[str, Any]:
        """发送PUT请求并返回JSON响应"""
        response = self.request("PUT", endpoint, json_data=data, **kwargs)
        return response.json()

    def delete(self, endpoint: str, **kwargs) -> requests.Response:
        """发送DELETE请求"""
        return self.request("DELETE", endpoint, **kwargs)

    def delete_json(self, endpoint: str, **kwargs) -> Dict[str, Any]:
        """发送DELETE请求"""
        response = self.request("DELETE", endpoint, **kwargs)
        return response.json()

    def patch(self, endpoint: str, **kwargs) -> requests.Response:
        """发送PATCH请求"""
        return self.request("PATCH", endpoint, **kwargs)

    def close(self):
        """关闭会话"""
        self.session.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()