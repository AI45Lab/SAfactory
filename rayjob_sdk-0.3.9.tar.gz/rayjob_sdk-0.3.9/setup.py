from setuptools import setup, find_packages

setup(
    name="rayjob_sdk",                   # 包的名称
    version="0.3.9",                     # 包的版本
    packages=find_packages(),            # 自动发现所有的包
    install_requires=[                   # 依赖的外部库
        "requests>=2.25.0",              # 依赖的 requests 库
        "dataclasses-json>0.6.4",      # 依赖的 dataclasses-json 库
    ],
    author="Your Name",                  # 作者
    author_email="your.email@example.com",# 作者的邮箱
    description="SDK for interacting with RayJob API", # 简短描述
    long_description=open('README.md',encoding="utf-8").read(), # 从 README 文件获取详细描述
    long_description_content_type="text/markdown",  # 格式
    url="https://example.com/yourusername/rayjob_sdk",  # GitHub 地址
)
